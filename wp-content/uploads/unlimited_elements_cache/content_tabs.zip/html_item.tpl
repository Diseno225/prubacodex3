{# twig vars #}{##}
{% set tabid = "ue-tab" ~ item.item_index %}
{% if item.tab_id is not empty %}
  {% set tabid = item.tab_id %}
{% endif %}
{# twig vars #}{##}

<li class="{{item.item_repeater_class}}">  	
  <a href="javascript:void(0);" data-content-id="{{item.item_id}}" {% if set_url_hash == "true" %} id="{{tabid}}"{% endif %} data-hash-id="#{{tabid}}" class="ue-tab-btn">
    {% if item.graphic_element == "icon" %}<div class="ue-graphic-element"><span class="ue-ge-icon">{{item.icon_html|raw}}</span></div>{% endif %}
    {% if item.graphic_element == "image" %}<div class="ue-graphic-element"><span class="ue-ge-icon"><img src="{{item.image_ge}}"></span></div>{% endif %}
    {% if item.graphic_element == "text" %}<div class="ue-graphic-element"><span class="ue-ge-text">{{item.graphic_element_text|raw}}</span></div>{% endif %}	   
    <{{text_tag_wrapper}}>{{item.title|raw}}</{{text_tag_wrapper}}>
  </a>      
</li>